<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class BooksResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'Kategori' => ucfirst($this->category->nama_kategori),
            'Judul' => $this->judul,
            'Pengarang' => $this->pengarang,
            'Penerbit' => $this->penerbit,
            'Jumlah Halaman' => $this->jumlah_halaman,
            'Tahun Terbit' => $this->tahun_terbit,
            'Edisi Buku' => $this->edisi_buku,
            'Jumlah Buku' => $this->jumlah_buku,
            'Dibuat pada' => $this->created_at,
            'Dibuat Oleh' => $this->user->name,
        ];
    }
}
