<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class BookCategoriesResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'Nama Kategori' => ucfirst($this->nama_kategori),
            'Deskripsi' => $this->deskripsi,
            'Dibuat Oleh' => $this->user->name,
            'Dibuat pada' => $this->created_at
        ];
    }
}
